Compile with XeLaTeX: xelatex supplement; xelatex main; xelatex supplement; xelatex main (main uses xr to resolve S-references from supplement.aux).
