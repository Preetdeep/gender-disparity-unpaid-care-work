params <-
list(blind = TRUE)

## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = FALSE, message = FALSE, warning = FALSE,
                      fig.align = "center", fig.pos = "H", out.width = "90%")
TUS_ROOT <- normalizePath("../..")
source(file.path(TUS_ROOT, "R", "setup.R"))
pd <- load_panel()
V  <- panel_validation(pd)
require_cols(pd, c("marital", "rel", "spouse_pid", "edu_tier", "employed"), "Paper 05")


## ----watermark, results="asis"------------------------------------------------
if (TUS_SYNTHETIC) cat("\\SetWatermarkText{SYNTHETIC TEST DATA}")


## ----helpers-local------------------------------------------------------------
# Local text helpers. "mins" gives magnitude plus direction word, never a signed
# number followed by a direction word.
mins <- function(e, more = "more", less = "fewer", d = 0) {
  if (is.null(e$est) || is.na(e$est)) return("[not estimable]")
  v <- .fmt(abs(e$est), d)
  paste0(v, if (v == "1") " minute " else " minutes ", more_less(e$est, more, less))
}
# Demographic Research style: no p-value stars and no claims of statistical testing;
# uncertainty is reported as 95% confidence intervals (estimate +/- 1.96 FSU-clustered SEs).
ci_lo <- function(e) e$est - 1.96 * e$se
ci_hi <- function(e) e$est + 1.96 * e$se
cell <- function(e, d = 1) {
  if (is.null(e$est) || is.na(e$est)) return("--")
  paste0(.fmt(e$est, d), " [", .fmt(ci_lo(e), d), ", ", .fmt(ci_hi(e), d), "]")
}
# CI of the magnitude in the stated direction (so "12.3 minutes (95% CI [4.5, 20.1]) less").
dir_ci <- function(e, d = 1) {
  lo <- ci_lo(e); hi <- ci_hi(e)
  if (e$est < 0) { t <- lo; lo <- -hi; hi <- -t }
  paste0("95% CI [", .fmt(lo, d), ", ", .fmt(hi, d), "]")
}
est_se <- function(e, digits = 1, unit = "minutes") {
  if (is.null(e$est) || is.na(e$est)) return("not estimable")
  paste0(.fmt(e$est, digits), if (nzchar(unit)) paste0(" ", unit) else "",
         " (95% CI [", .fmt(ci_lo(e), digits), ", ", .fmt(ci_hi(e), digits), "])")
}
diff_txt <- function(e, more = "more", less = "less", digits = 1, unit = "minutes") {
  if (is.na(e$est)) return("[not estimable]")
  paste0(.fmt(abs(e$est), digits), if (nzchar(unit)) paste0(" ", unit) else "",
         " (", dir_ci(e, digits), ") ", more_less(e$est, more, less))
}
diff_pp <- function(e, more = "higher", less = "lower", digits = 1) {
  if (is.null(e$est) || is.na(e$est)) return("not estimable")
  e100 <- list(est = 100 * e$est, se = 100 * e$se)
  paste0(.fmt(abs(e100$est), digits), " percentage points (", dir_ci(e100, digits), ") ", more_less(e$est, more, less))
}
mins_ci <- function(e, more = "more", less = "fewer", d = 0) {
  if (is.null(e$est) || is.na(e$est)) return("[not estimable]")
  v <- .fmt(abs(e$est), d)
  # used in the raw-LaTeX abstract, so the percent sign is escaped
  paste0(v, if (v == "1") " minute " else " minutes ", more_less(e$est, more, less), " (", gsub("%", "\\\\%", dir_ci(e, d)), ")")
}
# Direction and "clear difference" flags are read from the 95% CI, not from p-values.
is_sig <- function(e) isTRUE(!is.na(e$est) && !is.na(e$se) && abs(e$est) > 1.96 * e$se)
is_pos <- function(e) isTRUE(is_sig(e) && e$est > 0)
is_neg <- function(e) isTRUE(is_sig(e) && e$est < 0)
ci_txt <- function(est, se, f = f1, pct = FALSE) {   # vectorised "est [lo, hi]" for couple-table cells
  g <- if (pct) function(x) pctx(x, 0) else f
  paste0(g(est), " [", g(est - 1.96 * se), ", ", g(est + 1.96 * se), "]")
}
na_e <- list(est = NA, se = NA, p = NA)
wvar <- function(x, w) { ok <- !is.na(x) & !is.na(w); m <- wmean(x[ok], w[ok]); sum(w[ok] * (x[ok] - m)^2) / sum(w[ok]) }
std_diff <- function(x1, w1, x0, w0) (wmean(x1, w1) - wmean(x0, w0)) / sqrt((wvar(x1, w1) + wvar(x0, w0)) / 2)
kish <- function(w) sum(w)^2 / sum(w^2)


## ----sample-------------------------------------------------------------------
R <- CODE$relation
# All derived columns are created on A BEFORE the sex subsets are taken.
A <- pd[age >= 20 & age <= 39 & sex %in% c("Men", "Women") & marital %in% c(1, 2)]
A[, `:=`(sex = droplevels(sex), age_f = factor(age), unpaid = unpaid_domestic + unpaid_care,
         grad = as.integer(edu_tier == "Graduate and above"),
         secplus = as.integer(edu_tier %in% c("Secondary / higher secondary", "Graduate and above")),
         scst = as.integer(social_group_f %in% c("SC", "ST")),
         muslim = as.integer(religion_f == "Muslim"),
         student = as.integer(pas_group == "Student"))]
# Residence type of the married: junior couple in the parental household
# (women: daughter-in-law of head, rel 4; men: married son of head, rel 3),
# head couple with a parent generation present (rel 7 in household), head couple without.
A[, res := fcase(married == 0, "nm",
                 female == 1 & rel == R["child_spouse"], "junior",
                 female == 0 & rel == R["married_child"], "junior",
                 rel %in% R[c("head", "spouse")] & hh_n_parent_gen > 0, "head_old",
                 rel %in% R[c("head", "spouse")] & hh_n_parent_gen == 0, "nuclear",
                 default = "other")]
A[, res := factor(res, levels = c("nm", "nuclear", "head_old", "junior", "other"))]
A[, grp := factor(paste(sex, ifelse(married == 1, "married", "never married")),
                  levels = c("Women never married", "Women married", "Men never married", "Men married"))]
W <- A[female == 1]; M <- A[female == 0]

part <- PARTITION
part_lab <- c(employment = "Employment (incl. travel)", ownuse_goods = "Own-use production of goods",
              unpaid_domestic = "Unpaid domestic services", unpaid_care = "Unpaid caregiving",
              volunteer = "Volunteering", learning = "Learning", social_all = "Socializing, community, religion",
              leisure_all = "Culture, leisure, media, sport", selfcare_all = "Self-care incl. sleep")
extra <- c("sleep", "socialising", "exercise_sport", "religious", "mass_media")
extra_lab <- c(sleep = "\\quad of which: sleep", socialising = "\\quad of which: socializing",
               exercise_sport = "\\quad of which: exercise and sport",
               religious = "\\quad of which: religious practice", mass_media = "\\quad of which: mass media")
outs <- c(part, extra, "unpaid")

# Baseline controls: characteristics fixed before or at marriage. Household
# composition and consumption are possible consequences of marriage (moving into
# the husband's household), so they enter only the extended specification.
controls <- ctrl(A, c("i(edu_tier)", "urban", "i(social_group_f)", "i(religion_f)", "proxy_report"))
controls_ext <- ctrl(A, c("i(edu_tier)", "urban", "i(social_group_f)", "i(religion_f)", "proxy_report",
                          "i(mpce_quintile)", "hh_size", "hh_n_60plus"))
FE <- fe(A, c("state", "dow", "age_f"))
fit <- function(y, d, rhs = "married", ctl = controls, fes = FE)
  reg(as.formula(paste(y, "~", rhs, "+", ctl, fes)), d)
k_of <- function(m, term = "married") coef_of(m, term)

mW <- setNames(lapply(outs, fit, d = W), outs)
mM <- setNames(lapply(outs, fit, d = M), outs)
kW <- function(y) k_of(mW[[y]]); kM <- function(y) k_of(mM[[y]])
bW <- sapply(outs, function(y) cf(mW[[y]], "married")); bM <- sapply(outs, function(y) cf(mM[[y]], "married"))
k_uw <- kW("unpaid"); k_um <- kM("unpaid")

# Pooled gendered marriage gap with sex-specific age, state and day effects
FEdd <- if (nzchar(FE)) "| state^female + dow^female + age_f^female" else ""
dd <- reg(as.formula(paste("unpaid ~ married * female +", controls, FEdd)), A)
k_dd <- k_of(dd, "married:female")

# Sources of women's extra unpaid minutes: the other seven divisions
src <- bW[setdiff(part, c("unpaid_domestic", "unpaid_care"))]
src_neg <- sort(src[!is.na(src) & src < 0])
tot_neg <- -sum(src_neg)
src_name <- function(i) if (length(src_neg) >= i) tolower(part_lab[names(src_neg)[i]]) else NA_character_
src_min <- function(i) if (length(src_neg) >= i) f0(abs(src_neg[i])) else "--"
share_emp_learn <- if (tot_neg > 0) sum(-src_neg[names(src_neg) %in% c("employment", "learning")]) / tot_neg else NA
share_leis <- if (tot_neg > 0) sum(-src_neg[names(src_neg) %in% c("social_all", "leisure_all")]) / tot_neg else NA
share_self <- if (tot_neg > 0) sum(-src_neg[names(src_neg) == "selfcare_all"]) / tot_neg else NA

# Descriptive context
share_married_w <- wmean(W$married, W$weight); share_married_m <- wmean(M$married, M$weight)
evermar_w3539 <- pd[female == 1 & age >= 35 & age <= 39 & !is.na(marital), wmean(as.integer(marital %in% 2:4), weight)]
evermar_m3539 <- pd[female == 0 & age >= 35 & age <= 39 & !is.na(marital), wmean(as.integer(marital %in% 2:4), weight)]
Wm <- W[married == 1]
sh_res <- sapply(c("nuclear", "head_old", "junior", "other"), function(l) wmean(as.integer(Wm$res == l), Wm$weight))
Mm <- M[married == 1]
sh_res_m <- sapply(c("nuclear", "head_old", "junior", "other"), function(l) wmean(as.integer(Mm$res == l), Mm$weight))
stud_w_nm <- W[married == 0, wmean(student, weight)]; stud_w_m <- W[married == 1, wmean(student, weight)]
emp_w_nm <- W[married == 0, wmean(employed, weight)]; emp_w_m <- W[married == 1, wmean(employed, weight)]


## ----residence----------------------------------------------------------------
# Heterogeneity by residence type: each married group against the same never-married group
outs_res <- c(part, "sleep", "unpaid")
res_rhs <- "i(res, ref = 'nm')"
rW <- setNames(lapply(outs_res, function(y) reg(as.formula(paste(y, "~", res_rhs, "+", controls, FE)), W)), outs_res)
rM <- setNames(lapply(outs_res, function(y) reg(as.formula(paste(y, "~", res_rhs, "+", controls, FE)), M)), outs_res)
kr <- function(mods, y, l) k_of(mods[[y]], paste0("res::", l))
# Direct test among married women: junior (daughter-in-law) versus nuclear
Wm2 <- copy(Wm)[res %in% c("nuclear", "head_old", "junior")]
Wm2[, res := droplevels(res)]
Wm2[, res := relevel(res, ref = "nuclear")]
dil <- function(y) k_of(reg(as.formula(paste(y, "~ i(res, ref = 'nuclear') +", controls, FE)), Wm2), "res::junior")
k_dil <- setNames(lapply(c("unpaid", "employment", "social_all", "leisure_all", "sleep", "ownuse_goods"), dil),
                  c("unpaid", "employment", "social_all", "leisure_all", "sleep", "ownuse_goods"))


## ----selection----------------------------------------------------------------
# (1) Restriction to ages 20-26, where never-married women are least selected
W26 <- W[age <= 26]; M26 <- M[age <= 26]
FE26 <- fe(W26, c("state", "dow", "age_f"))
m26W <- setNames(lapply(outs_res, function(y) fit(y, W26, fes = FE26)), outs_res)
m26M <- setNames(lapply(outs_res, function(y) fit(y, M26, fes = FE26)), outs_res)
share_married_w26 <- wmean(W26$married, W26$weight)

# (2) DiNardo-Fortin-Lemieux reweighting: never-married reweighted to the
# covariate distribution of the married (ATT on observables).
dfl <- function(d, trim = NULL) {
  d <- copy(d)
  vars <- c("age_f", "state", "edu_tier", "urban", "social_group_f", "religion_f")
  vars <- vars[vars %in% names(d)]
  vars <- vars[vapply(vars, function(v) uniqueN(na.omit(d[[v]])) > 1, logical(1))]
  rhs <- paste(ifelse(vars == "state", "factor(state)", vars), collapse = " + ")
  d[, w0 := weight / mean(weight)]
  g <- tryCatch(glm(as.formula(paste("married ~", rhs)), data = d, family = quasibinomial(),
                    weights = w0, na.action = na.exclude), error = function(e) NULL)
  if (is.null(g)) return(NULL)
  d[, ps := as.numeric(fitted(g))]
  d <- d[!is.na(ps)]
  if (!is.null(trim)) d <- d[ps >= trim[1] & ps <= trim[2]]
  cap <- 0.99
  attr_cap <- d[married == 0, wmean(as.integer(ps > cap), weight)]
  d[, ps_c := pmin(ps, cap)]
  d[married == 0, weight := weight * ps_c / (1 - ps_c)]
  d[married == 0, weight := weight * d[married == 1, sum(weight)] / sum(weight)]
  attr(d, "share_capped") <- attr_cap
  d
}
Wr <- dfl(W); Mr <- dfl(M)
FEr <- if (!is.null(Wr)) fe(Wr, c("state", "dow", "age_f")) else ""
mrW <- if (!is.null(Wr)) setNames(lapply(outs_res, function(y) fit(y, Wr, fes = FEr)), outs_res) else NULL
mrM <- if (!is.null(Mr)) setNames(lapply(outs_res, function(y) fit(y, Mr, fes = FEr)), outs_res) else NULL
k_rw_raw <- if (!is.null(Wr)) k_of(reg(unpaid ~ married, Wr)) else na_e
ess_nm_w <- if (!is.null(Wr)) kish(Wr[married == 0]$weight) else NA
n_nm_w <- W[married == 0, .N]
cap_w <- if (!is.null(Wr)) attr(Wr, "share_capped") else NA
# Trimming checks (Crump et al. 2009 style): drop propensities outside [0.05, 0.95] or [0.10, 0.90]
trim_res <- lapply(list(t05 = c(0.05, 0.95), t10 = c(0.10, 0.90)), function(tr) {
  d <- dfl(W, trim = tr); if (is.null(d)) return(list(k = na_e, ess = NA, n = NA, emp = na_e, lrn = na_e))
  ff <- fe(d, c("state", "dow", "age_f"))
  list(k = k_of(fit("unpaid", d, fes = ff)), emp = k_of(fit("employment", d, fes = ff)),
       lrn = k_of(fit("learning", d, fes = ff)), ess = kish(d[married == 0]$weight), n = nrow(d))
})
# Marriage versus motherhood: women in households with no child under six
W_nc <- W[hh_n_under6 == 0]
FEnc <- fe(W_nc, c("state", "dow", "age_f"))
k_nc_u <- k_of(fit("unpaid", W_nc, fes = FEnc)); k_nc_d <- k_of(fit("unpaid_domestic", W_nc, fes = FEnc))
k_nc_c <- k_of(fit("unpaid_care", W_nc, fes = FEnc))
share_married_nc <- wmean(W_nc$married, W_nc$weight); n_nc <- nrow(W_nc)
k_dom_w <- kW("unpaid_domestic"); k_care_w <- kW("unpaid_care")

# Covariate balance before and after reweighting (women)
bal_vars <- c(age = "Age (years)", secplus = "Secondary education or more", grad = "Graduate",
              urban = "Urban", scst = "Scheduled Caste or Tribe", muslim = "Muslim")
bal <- if (!is.null(Wr)) data.frame(
  Covariate = unname(bal_vars),
  Married = sapply(names(bal_vars), function(v) f2(W[married == 1, wmean(get(v), weight)])),
  `Never married` = sapply(names(bal_vars), function(v) f2(W[married == 0, wmean(get(v), weight)])),
  `Never married, reweighted` = sapply(names(bal_vars), function(v) f2(Wr[married == 0, wmean(get(v), weight)])),
  `Std. diff. before` = sapply(names(bal_vars), function(v) f2(std_diff(W[married == 1][[v]], W[married == 1]$weight,
                                                                       W[married == 0][[v]], W[married == 0]$weight))),
  `Std. diff. after` = sapply(names(bal_vars), function(v) f2(std_diff(Wr[married == 1][[v]], Wr[married == 1]$weight,
                                                                      Wr[married == 0][[v]], Wr[married == 0]$weight))),
  check.names = FALSE) else NULL
max_sd_after <- if (!is.null(Wr)) max(abs(sapply(names(bal_vars), function(v)
  std_diff(Wr[married == 1][[v]], Wr[married == 1]$weight, Wr[married == 0][[v]], Wr[married == 0]$weight))), na.rm = TRUE) else NA

# (3) Bias-adjusted estimates and breakdown values (Oster 2019)
ost_vars <- c("unpaid", "employment", "learning", "social_all", "leisure_all", "sleep")
ost <- lapply(ost_vars, function(y) {
  m0 <- reg(as.formula(paste(y, "~ married")), W); m1 <- mW[[y]]
  if (is.null(m0) || is.null(m1)) return(c(b0 = NA, b1 = NA, bstar = NA, dstar = NA))
  b0 <- cf(m0, "married"); b1 <- cf(m1, "married")
  r0 <- fixest::r2(m0, "r2"); r1 <- fixest::r2(m1, "r2"); rmax <- min(1, 1.3 * r1)
  bstar <- if (isTRUE(r1 > r0)) oster_beta(m0, m1, "married") else NA
  dstar <- if (isTRUE(r1 > r0) && isTRUE(abs(b0 - b1) > 1e-8)) b1 * (r1 - r0) / ((b0 - b1) * (rmax - r1)) else NA
  c(b0 = b0, b1 = b1, bstar = bstar, dstar = dstar)
})
ost <- setNames(as.data.frame(do.call(rbind, ost)), c("b0", "b1", "bstar", "dstar"))
rownames(ost) <- ost_vars
ost_lab <- c(unpaid = "Unpaid domestic and care work", employment = part_lab[["employment"]],
             learning = part_lab[["learning"]], social_all = part_lab[["social_all"]],
             leisure_all = part_lab[["leisure_all"]], sleep = "Sleep")
bstar_u <- ost["unpaid", "bstar"]; dstar_u <- ost["unpaid", "dstar"]

# (4) Gradient of the unpaid-work gap across age bands
bands <- list(`20-22` = c(20, 22), `23-25` = c(23, 25), `26-29` = c(26, 29), `30-34` = c(30, 34), `35-39` = c(35, 39))
grad_tab <- rbindlist(lapply(names(bands), function(b) {
  lo <- bands[[b]][1]; hi <- bands[[b]][2]
  rbindlist(lapply(c("Women", "Men"), function(s) {
    d <- A[sex == s & age >= lo & age <= hi]
    e <- k_of(fit("unpaid", d, fes = fe(d, c("state", "dow", "age_f"))))
    data.table(band = b, sex = s, est = e$est, se = e$se, p = e$p, nm_share = wmean(1 - d$married, d$weight), n = nrow(d))
  }))
}))
g_first <- grad_tab[sex == "Women"][1]; g_last <- grad_tab[sex == "Women"][.N]


## ----couples------------------------------------------------------------------
# Within-couple gaps (linked spouses), wives aged 20-59
C <- pd[female == 1 & married == 1 & !is.na(spouse_pid) & age >= 20 & age <= 59]
C[, `:=`(gap_unpaid = unpaid_total - spouse_unpaid_total,
         gap_paid = spouse_employment - employment,
         gap_free = spouse_free_time - free_time,
         share_w = fifelse(unpaid_total + spouse_unpaid_total > 0,
                           unpaid_total / (unpaid_total + spouse_unpaid_total), NA_real_),
         age_f = factor(age),
         agegap = spouse_age - age)]
C[, wife_works := factor(fcase(employed == 1, "Wife employed", employed == 0, "Wife not employed"),
                         levels = c("Wife not employed", "Wife employed"))]
C[, rel_edu := factor(fcase(is.na(edu_tier) | is.na(spouse_edu_tier), NA_character_,
                            as.integer(edu_tier) > as.integer(spouse_edu_tier), "Wife more educated",
                            as.integer(edu_tier) == as.integer(spouse_edu_tier), "Same education tier",
                            default = "Husband more educated"),
                      levels = c("Husband more educated", "Same education tier", "Wife more educated"))]
C[, res_c := factor(fcase(rel == R["child_spouse"], "Wife is daughter-in-law of head",
                          rel %in% R[c("head", "spouse")] & hh_n_parent_gen > 0, "Head couple, parent generation present",
                          rel %in% R[c("head", "spouse")] & hh_n_parent_gen == 0, "Head couple, no parent generation",
                          default = NA_character_),
                    levels = c("Head couple, no parent generation", "Head couple, parent generation present",
                               "Wife is daughter-in-law of head"))]
C[, agecat := factor(fcase(is.na(agegap), NA_character_,
                           agegap <= 0, "Husband same age or younger",
                           agegap <= 3, "Husband older by 1-3 years",
                           agegap <= 6, "Husband older by 4-6 years",
                           agegap <= 9, "Husband older by 7-9 years",
                           default = "Husband older by 10+ years"),
                     levels = c("Husband same age or younger", "Husband older by 1-3 years", "Husband older by 4-6 years",
                                "Husband older by 7-9 years", "Husband older by 10+ years"))]
C[, agegap_c := pmin(pmax(agegap, -5), 15)]
C[, spouse_dow := pd$dow[match(spouse_pid, pd$pid)]]
same_dow <- if ("dow" %in% names(C)) C[!is.na(dow) & !is.na(spouse_dow), wmean(as.integer(dow == spouse_dow), weight)] else NA

cg <- est_mean(C, "gap_unpaid"); cgp <- est_mean(C, "gap_paid"); cgf <- est_mean(C, "gap_free")
csh <- est_mean(C, "share_w")
k_cg <- list(est = cg$est, se = cg$se); k_cgp <- list(est = cgp$est, se = cgp$se); k_cgf <- list(est = cgf$est, se = cgf$se)

grp_block <- function(by, title) {
  g1 <- est_mean(C, "gap_unpaid", by); g2 <- est_mean(C, "share_w", by); g3 <- est_mean(C, "gap_paid", by)
  g2 <- g2[match(g1$group, g2$group), ]; g3 <- g3[match(g1$group, g3$group), ]
  rbind(data.frame(Group = title, U = "", S = "", P = "", N = ""),
        data.frame(Group = paste0("\\quad ", g1$group),
                   U = ci_txt(g1$est, g1$se),
                   S = ci_txt(g2$est, g2$se, pct = TRUE),
                   P = ci_txt(g3$est, g3$se),
                   N = fn(g1$n)))
}
cg_emp <- est_mean(C, "gap_unpaid", "wife_works")
g_emp <- function(l) { x <- cg_emp$est[cg_emp$group == l]; if (length(x)) x else NA }
e_emp <- est_gap(C, "gap_unpaid", "wife_works", "Wife not employed", "Wife employed")
e_edu <- est_gap(C, "gap_unpaid", "rel_edu", "Husband more educated", "Wife more educated")
e_res <- est_gap(C, "gap_unpaid", "res_c", "Head couple, no parent generation", "Wife is daughter-in-law of head")

# Adjusted associations
ctl_c <- ctrl(C, c("i(edu_tier)", "i(spouse_edu_tier)", "urban", "i(social_group_f)", "i(religion_f)"))
FEc <- fe(C, c("state", "dow", "age_f"))
k_ag <- k_of(reg(as.formula(paste("gap_unpaid ~ agegap_c +", ctl_c, FEc)), C), "agegap_c")
k_ag_sh <- k_of(reg(as.formula(paste("share_w ~ agegap_c +", ctl_c, FEc)), C), "agegap_c")
k_res_adj <- k_of(reg(as.formula(paste("gap_unpaid ~ i(res_c, ref = 'Head couple, no parent generation') +", ctl_c, FEc)), C),
                  "res_c::Wife is daughter-in-law of head")
cg_age <- est_mean(C, "gap_unpaid", "agecat")
ag_raw_first <- cg_age$est[1]; ag_raw_last <- cg_age$est[nrow(cg_age)]
med_agegap <- if (any(!is.na(C$agegap))) wquantile(C$agegap[!is.na(C$agegap)], C$weight[!is.na(C$agegap)], 0.5) else NA


## ----widowhood----------------------------------------------------------------
O <- pd[age >= 50 & age <= 79 & sex %in% c("Men", "Women") & marital %in% c(2, 3)]
O[, `:=`(widowed = as.integer(marital == 3), age_f = factor(age))]
FEo <- fe(O, c("state", "dow", "age_f"))
co <- ctrl(O, c("i(edu_tier)", "urban", "i(social_group_f)", "i(religion_f)", "proxy_report"))
fo <- function(y, d) k_of(reg(as.formula(paste(y, "~ widowed +", co, FEo)), d), "widowed")
wid <- data.frame(Outcome = c("Unpaid domestic and care", "Employment (incl. travel)", "Free time (socializing and leisure)",
                              "Sleep", "Socializing", "Exercise and sport", "Religious practice"),
                  var = c("unpaid_total", "employment", "free_time", "sleep", "socialising", "exercise_sport", "religious"))
widW <- lapply(wid$var, function(y) fo(y, O[female == 1])); widM <- lapply(wid$var, function(y) fo(y, O[female == 0]))
wid$Women <- sapply(widW, cell); wid$Men <- sapply(widM, cell)
k_wid_uw <- widW[[1]]; k_wid_um <- widM[[1]]


## ----robustness---------------------------------------------------------------
rob_spec <- list(
  "Baseline (ages 20--39)" = list(d = function(X) X, ctl = controls),
  "Extended controls (consumption, household size, members 60+)" = list(d = function(X) X, ctl = controls_ext),
  "Ages 20--26" = list(d = function(X) X[age <= 26], ctl = controls),
  "Ages 20--29" = list(d = function(X) X[age <= 29], ctl = controls),
  "Ages 30--39" = list(d = function(X) X[age >= 30], ctl = controls),
  "Self-reported diaries only" = list(d = function(X) if ("proxy_report" %in% names(X)) X[proxy_report == 0] else X[0], ctl = controls),
  "Urban" = list(d = function(X) X[urban == 1], ctl = controls),
  "Rural" = list(d = function(X) X[urban == 0], ctl = controls),
  "Excluding current students" = list(d = function(X) X[student == 0], ctl = controls),
  "Normal diary days only" = list(d = function(X) if ("type_day" %in% names(X)) X[type_day == CODE$type_of_day["normal"]] else X[0], ctl = controls)
)
rob_one <- function(s, dat) {
  d <- s$d(dat)
  if (!nrow(d)) return(na_e)
  k_of(fit("unpaid", d, ctl = s$ctl, fes = fe(d, c("state", "dow", "age_f"))))
}
robW <- lapply(rob_spec, rob_one, dat = W); robM <- lapply(rob_spec, rob_one, dat = M)
rob_est_w <- sapply(robW, function(e) e$est)
rob_range <- range(rob_est_w, na.rm = TRUE)
rob_ok <- robW[!sapply(robW, function(e) is.na(e$est))]
rob_all_pos <- length(rob_ok) > 0 && all(sapply(rob_ok, is_pos))


## ----text-flags---------------------------------------------------------------
# Results-dependent sentences, built from the estimates.
h1_supported <- is_pos(k_dd) && is_pos(k_uw)
specialisation <- isTRUE(share_emp_learn > 0.5)
sleep_txt <- iff(is_neg(kW("sleep")), paste0("Married women slept ", mins_ci(kW("sleep"), less = "less"), " than never-married women"),
                 iff(is_pos(kW("sleep")), paste0("Married women slept ", mins_ci(kW("sleep"), less = "less"), " than never-married women"),
                     "Sleep did not differ detectably between married and never-married women"))
dil_dir <- iff(is_pos(k_dil$unpaid), "hierarchy", iff(is_neg(k_dil$unpaid), "substitution", "neither"))
emp_dir <- iff(is_neg(e_emp), "smaller", iff(is_pos(e_emp), "larger", "similar"))
edu_dir <- iff(is_neg(e_edu), "smaller", iff(is_pos(e_edu), "larger", "similar"))
ag_dir <- iff(is_pos(k_ag), "larger", iff(is_neg(k_ag), "smaller", "unrelated"))


## ----intro-numbers, include=FALSE---------------------------------------------
intro_src <- iff(tot_neg > 0,
  paste0("For women, the largest offsetting reductions are in ", src_name(1), " (", src_min(1), " minutes)",
         if (length(src_neg) >= 2) paste0(" and ", src_name(2), " (", src_min(2), " minutes)") else "", "."),
  "No other division is detectably lower for married women, so the time budget does not identify a single offsetting activity.")


## ----tab-desc-----------------------------------------------------------------
dvars <- c(employment = "Employment (incl. travel), min", ownuse_goods = "Own-use production of goods, min",
           unpaid_domestic = "Unpaid domestic services, min", unpaid_care = "Unpaid caregiving, min",
           learning = "Learning, min", social_all = "Socializing, community, religion, min",
           leisure_all = "Culture, leisure, media, sport, min", selfcare_all = "Self-care incl. sleep, min",
           sleep = "\\quad of which: sleep, min")
svars <- c(age = "Age, years", employed = "Employed (usual status)", student = "Current student",
           grad = "Graduate", urban = "Urban")
glev <- levels(A$grp)
desc <- rbind(
  data.frame(Variable = unname(dvars), sapply(glev, function(g) sapply(names(dvars), function(v) f0(A[grp == g, wmean(get(v), weight)]))),
             check.names = FALSE),
  data.frame(Variable = unname(svars), sapply(glev, function(g) sapply(names(svars), function(v) {
    x <- A[grp == g, wmean(get(v), weight)]; if (v == "age") f1(x) else pctx(x, 0) })), check.names = FALSE),
  data.frame(Variable = "Diaries (N)", t(sapply(glev, function(g) fn(A[grp == g, .N]))), check.names = FALSE))
names(desc) <- c("", "Women, never married", "Women, married", "Men, never married", "Men, married")
tab(desc, caption = paste0("Weighted means by sex and marital status, ages 20--39", syn_note()), label = "desc",
    align = c("l", "r", "r", "r", "r"), escape = FALSE,
    notes = "Minutes per day from major activities; the nine divisions (eight shown plus volunteering) sum to 1,440. Weighted by survey multipliers.")


## ----tab-decomp---------------------------------------------------------------
dtab <- data.frame(Activity = c(part_lab[part], "Sum of the nine divisions", extra_lab[extra], "Unpaid work (domestic + care)"),
                   Women = c(sapply(part, function(y) cell(kW(y))), f1(sum(bW[part])),
                             sapply(extra, function(y) cell(kW(y))), cell(k_uw)),
                   Men = c(sapply(part, function(y) cell(kM(y))), f1(sum(bM[part])),
                           sapply(extra, function(y) cell(kM(y))), cell(k_um)))
tab(dtab, caption = paste0("Married minus never-married, minutes per day, ages 20--39", syn_note()), label = "decomp",
    align = c("l", "r", "r"), escape = FALSE,
    notes = "Coefficients on currently married from separate regressions by sex, with single-year age, state and day-of-week fixed effects and controls for education, urban residence, caste, religion and proxy report. 95% confidence intervals in brackets, from FSU-clustered standard errors. The nine divisions partition the day, so their coefficients sum to zero.")


## ----tab-selection------------------------------------------------------------
sel_cell <- function(mods, y) if (is.null(mods)) "--" else cell(k_of(mods[[y]]))
stab <- data.frame(Activity = c(part_lab[part], "\\quad of which: sleep", "Unpaid work (domestic + care)"),
                   Baseline = sapply(outs_res, function(y) cell(kW(y))),
                   `Ages 20--26` = sapply(outs_res, function(y) sel_cell(m26W, y)),
                   Reweighted = sapply(outs_res, function(y) sel_cell(mrW, y)),
                   check.names = FALSE)
stab$`Bias-adjusted` <- sapply(outs_res, function(y) {
  k <- switch(y, unpaid = "unpaid", employment = "employment", learning = "learning", social_all = "social_all",
              leisure_all = "leisure_all", sleep = "sleep", NA)
  if (is.na(k)) "" else f1(ost[k, "bstar"]) })
stab$`Breakdown delta` <- sapply(outs_res, function(y) {
  k <- switch(y, unpaid = "unpaid", employment = "employment", learning = "learning", social_all = "social_all",
              leisure_all = "leisure_all", sleep = "sleep", NA)
  if (is.na(k)) "" else f2(ost[k, "dstar"]) })
tab(stab, caption = paste0("Women: married minus never-married under alternative treatments of selection, minutes per day", syn_note()),
    label = "selection", align = c("l", rep("r", 5)), escape = FALSE,
    notes = "Baseline: the decomposition for ages 20--39. Ages 20--26: same model on women aged 20--26. Reweighted: never-married women reweighted to the covariate distribution of married women (DiNardo-Fortin-Lemieux odds weights from a logit on single-year age, state, education, urban, caste and religion; propensities capped at 0.99), with the baseline controls. Bias-adjusted: Oster (2019) coefficient with delta = 1 and R-max = 1.3 times the controlled R-squared, relative to a regression on the married indicator alone. Breakdown delta: the delta at which the bias-adjusted coefficient is zero. 95% confidence intervals in brackets, from FSU-clustered standard errors.")


## ----tab-couple---------------------------------------------------------------
ctab <- rbind(
  data.frame(Group = "All linked couples", U = ci_txt(cg$est, cg$se),
             S = ci_txt(csh$est, csh$se, pct = TRUE),
             P = ci_txt(cgp$est, cgp$se), N = fn(cg$n)),
  grp_block("wife_works", "Wife's employment"),
  grp_block("rel_edu", "Relative education"),
  grp_block("res_c", "Residence"),
  grp_block("agecat", "Spousal age gap"))
names(ctab) <- c("", "Unpaid gap (W$-$H)", "Wife's unpaid share", "Employment gap (H$-$W)", "N")
tab(ctab, caption = paste0("Within-couple gaps, linked couples with wives aged 20--59", syn_note()), label = "couple",
    align = c("l", "r", "r", "r", "r"), escape = FALSE,
    notes = "Spouses linked through the household roster (head and spouse of head; married child of head and child's spouse where each is unique). Weighted by the wife's multiplier. 95% confidence intervals in brackets, from FSU-clustered standard errors.")


## ----fig-decomp, fig.cap = paste0("Married minus never-married minutes per day by activity division, ages 20--39. Bars for each sex sum to zero; lines are 95\\% confidence intervals.", syn_note()), fig.height = 3.8----
fd <- rbindlist(lapply(part, function(y) rbind(
  data.table(cat = part_lab[[y]], sex = "Women", b = kW(y)$est, se = kW(y)$se),
  data.table(cat = part_lab[[y]], sex = "Men", b = kM(y)$est, se = kM(y)$se))))
fd[, `:=`(cat = factor(cat, levels = rev(part_lab[part])), sex = factor(sex, levels = c("Women", "Men")))]
ggplot(fd, aes(b, cat, fill = sex)) +
  geom_col(position = position_dodge(0.75), width = 0.7) +
  geom_errorbarh(aes(xmin = b - 1.96 * se, xmax = b + 1.96 * se), position = position_dodge(0.75), height = 0.2, linewidth = 0.3) +
  geom_vline(xintercept = 0, linewidth = 0.3) + scale_fill_manual(values = SEX_COLS, name = NULL) +
  labs(x = "Minutes per day", y = NULL)


## ----tab-residence------------------------------------------------------------
rl <- c(nuclear = "No parent generation", head_old = "Parent generation present", junior = "Daughter-in-law / son")
short_lab <- c(employment = "Employment", ownuse_goods = "Own-use goods", unpaid_domestic = "Domestic services",
               unpaid_care = "Caregiving", volunteer = "Volunteering", learning = "Learning",
               social_all = "Social, community, religion", leisure_all = "Leisure, media, sport",
               selfcare_all = "Self-care", sleep = "\\quad of which: sleep", unpaid = "Unpaid work")
rtab <- data.frame(Activity = unname(short_lab[outs_res]),
                   sapply(names(rl), function(l) sapply(outs_res, function(y) cell(kr(rW, y, l)))),
                   sapply(names(rl), function(l) sapply(outs_res, function(y) cell(kr(rM, y, l)))),
                   check.names = FALSE)
names(rtab) <- c("Activity", "No parent gen.", "Parent gen.", "Daughter-in-law", "No parent gen.", "Parent gen.", "Married son")
kableExtra::add_header_above(tab(rtab, caption = paste0("Married minus never-married by residence type, minutes per day, ages 20--39", syn_note()),
    label = "residence", align = c("l", rep("r", 6)), escape = FALSE,
    notes = "Each married residence type is compared with never-married persons of the same sex. ``No parent gen.'': head or head's spouse, no parent or parent-in-law of the head in the household. ``Parent gen.'': head or head's spouse with a parent or parent-in-law of the head present. ``Daughter-in-law'': roster code 4 (women); ``Married son'': roster code 3 (men). Controls and fixed effects as in the baseline decomposition. 95% confidence intervals in brackets, from FSU-clustered standard errors."), c(" " = 1, "Women" = 3, "Men" = 3))


## ----fig-overlap, fig.cap = "Estimated propensity of being married, women aged 20--39, by marital status (survey-weighted densities)", fig.height = 3.2, fig.width = 6----
if (!is.null(Wr)) {
  op <- par(mar = c(4, 4, 1, 1))
  d1 <- density(Wr[married == 1]$ps, weights = Wr[married == 1]$w0 / sum(Wr[married == 1]$w0), from = 0, to = 1)
  d0 <- density(Wr[married == 0]$ps, weights = Wr[married == 0]$w0 / sum(Wr[married == 0]$w0), from = 0, to = 1)
  plot(d1, main = "", xlab = "Propensity score", ylab = "Density", ylim = c(0, max(d1$y, d0$y)), lwd = 2)
  lines(d0, lty = 2, lwd = 2)
  legend("topleft", c("Married", "Never married"), lty = c(1, 2), lwd = 2, bty = "n")
  par(op)
}


## ----tab-balance--------------------------------------------------------------
if (!is.null(bal)) tab(bal, caption = paste0("Covariate balance before and after reweighting, women aged 20--39", syn_note()), label = "balance",
                       align = c("l", rep("r", 5)),
                       notes = "Weighted means. Standardized difference: difference in means divided by the square root of the average of the two group variances. Reweighting uses DiNardo-Fortin-Lemieux odds weights (see the selection table in the main text).")


## ----tab-oster----------------------------------------------------------------
otab <- data.frame(Outcome = unname(ost_lab[rownames(ost)]), `Uncontrolled` = f1(ost$b0), `Controlled` = f1(ost$b1),
                   `Bias-adjusted` = f1(ost$bstar), `Breakdown delta` = f2(ost$dstar), check.names = FALSE)
tab(otab, caption = paste0("Coefficient stability for women: married minus never-married, minutes per day", syn_note()), label = "oster",
    align = c("l", "r", "r", "r", "r"),
    notes = "Uncontrolled: regression on the married indicator only. Controlled: baseline model. Bias-adjusted and breakdown delta as in the selection table (Oster 2019, R-max = 1.3 times the controlled R-squared).")


## ----fig-agegrad, fig.cap = paste0("Married minus never-married unpaid minutes per day by age band, with 95\\% confidence intervals. Labels give the weighted share never married in each band.", syn_note()), fig.height = 3.2----
gt <- copy(grad_tab)
gt[, `:=`(band = factor(band, levels = names(bands)), sex = factor(sex, levels = c("Women", "Men")))]
ggplot(gt, aes(band, est, colour = sex)) +
  geom_hline(yintercept = 0, linewidth = 0.3) +
  geom_pointrange(aes(ymin = est - 1.96 * se, ymax = est + 1.96 * se), position = position_dodge(0.4), size = 0.3) +
  geom_text(aes(label = pct(nm_share, 0), y = est + 1.96 * se), position = position_dodge(0.4), vjust = -0.6, size = 2.4, show.legend = FALSE) +
  scale_colour_manual(values = SEX_COLS, name = NULL) +
  scale_y_continuous(expand = expansion(mult = c(0.05, 0.18))) +
  labs(x = "Age band", y = "Minutes per day")


## ----fig-agegap, fig.cap = paste0("Wife minus husband unpaid minutes per day by spousal age gap, linked couples, with 95\\% confidence intervals.", syn_note()), fig.height = 2.9----
ga <- as.data.table(cg_age)
ga[, group := factor(group, levels = levels(C$agecat))]
ggplot(ga, aes(group, est)) +
  geom_hline(yintercept = 0, linewidth = 0.3) +
  geom_pointrange(aes(ymin = est - 1.96 * se, ymax = est + 1.96 * se), colour = SEX_COLS[["Women"]], size = 0.3) +
  scale_x_discrete(labels = function(x) gsub("Husband ", "", x)) +
  labs(x = "Husband's age relative to wife's", y = "Minutes per day")


## ----tab-widow----------------------------------------------------------------
tab(wid[, c("Outcome", "Women", "Men")], caption = paste0("Widowed minus married, minutes per day, ages 50--79", syn_note()), label = "widow",
    align = c("l", "r", "r"),
    notes = "Single-year age, state and day-of-week fixed effects; controls for education, urban residence, caste, religion and proxy report. 95% confidence intervals in brackets, from FSU-clustered standard errors.")


## ----tab-robust---------------------------------------------------------------
rb <- data.frame(Specification = names(rob_spec),
                 Women = sapply(robW, cell), Men = sapply(robM, cell))
tab(rb, caption = paste0("Married minus never-married unpaid minutes per day: robustness", syn_note()), label = "robust",
    align = c("l", "r", "r"),
    notes = "Each row re-estimates the baseline unpaid-work coefficient on the sample or with the controls named. Extended controls add consumption quintile, household size and the number of members aged 60 and above. Normal diary days exclude days the respondent reported as not normal. 95% confidence intervals in brackets, from FSU-clustered standard errors.")


## ----tab-flow-----------------------------------------------------------------
tab(diary_flow_table(pd), caption = "From the household roster to the analyzed diaries", label = "flow", align = c("l", "r"),
    notes = "All counts are computed from the microdata at knit time. Persons without diary records appear only on the household roster.")


## ----tab-codes----------------------------------------------------------------
tab(codes_table(c("paid_work","work_travel","ownuse_goods","dom_food","dom_cleaning","dom_textiles","dom_shopping","unpaid_domestic","care_child","care_dep_adult","unpaid_care","learning","free_time","sleep"), c("Employment","Employment-related travel","Own-use production of goods","Food and meals","Cleaning and upkeep","Care of textiles","Shopping","Unpaid domestic services (division 3)","Childcare","Care of dependent adults","Unpaid caregiving (division 4)","Learning","Free time (divisions 7 and 8)","Sleep")), caption = "Activity categories and ICATUS 2016 codes", label = "codes", align = c("l", "l"),
    notes = "Minutes are summed over major activities in the person-day diary. Codes are three-digit ICATUS 2016 codes as recorded in the survey.")


## ----tab-validation-----------------------------------------------------------
tab(validation_table(pd), caption = "Construction and validation of the person-day panel", label = "validation",
    align = c("l", "r"), notes = "All activity records are used; no row sampling.")

